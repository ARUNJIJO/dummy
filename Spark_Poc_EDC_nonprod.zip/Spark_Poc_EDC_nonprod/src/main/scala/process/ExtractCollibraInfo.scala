package ie.metlife.process

import ie.metlife.utils.Schema
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ExtractCollibraInfo {

  def apply(df: DataFrame, spark: SparkSession): DataFrame = {

    import spark.implicits._
    val schema = DataType.fromJson(Schema.collibraResponseSchema).asInstanceOf[StructType]
    val subSchema =DataType.fromJson(Schema.subSchema).asInstanceOf[StructType]

    val infoDf = df.withColumn("json",from_json($"value",schema))
      .withColumn("results",explode($"json.results"))
      .withColumn("results",to_json($"results"))
      .withColumn("results",from_json($"results",subSchema))
      .withColumn("collibra_id",$"results.id")
      .withColumn("name",split($"results.name","\\."))
      .withColumn("eaiCode",$"name".getItem(1))
      .withColumn("businessterms",$"name".getItem(0))

    infoDf.select($"collibra_id",$"eaiCode",$"businessterms")


  }

}

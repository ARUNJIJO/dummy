package ie.metlife.process

import ie.metlife.utils.Schema
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructType}

object ExtractEDCInfo {

  def apply(df: DataFrame, spark: SparkSession): DataFrame = {

    import spark.implicits._
    val schema = DataType.fromJson(Schema.edcIdsResponseSchema).asInstanceOf[StructType]


    val infoDf = df.withColumnRenamed("secondResponse", "value")
      .withColumn("serverName", regexp_extract($"value",
        ("name\":\"(\\S{4,35})\",\"classType\":\"com.infa.ldm.bgresource.BG_DL_Custom.Database_Host_NameClassifier\""), 1))
      .withColumn("ipAddress", regexp_extract($"value",
        ("name\":\"(\\S{8,18})\",\"classType\":\"com.infa.ldm.bgresource.BG_DL_Custom.Database_IP_AddressClassifier\""), 1))
      .withColumn("eaiCode", regexp_extract($"value",
        ("name\":\"(\\S{4,25})\",\"classType\":\"com.infa.ldm.bgresource.BG_DL_Custom.EAI_CodeClassifier\""), 1))
      //.withColumn("businessTerms", regexp_extract($"value",
      //("name\":\"(.{4,30})\",\"classType\":\"com.infa.ldm.bg.BGTerm\""), 1))
      .withColumn("businessterms", regexp_extract($"value",
        "\"businessTerms\":.+?name\":\"(.{4,4500})\",\"classType\":\"com.infa.ldm.bg.BGTerm\""
        , 1))

      .withColumn("businessterms", split($"businessterms", "\\|"))
      .withColumn("businessterms", explode($"businessterms"))
      .withColumn("technologyType", regexp_extract($"value",
        ("name\":\"(.{4,40})\",\"classType\":\"com.infa.ldm.bgresource.BG_DL_Custom.Database_Technology_TypeClassifier\""), 1))
      .withColumn("id", from_json($"value", schema).getField("id")
      )
      .withColumn("id", when($"id".isNull, regexp_extract($"value",
        ("id\":\"(\\S{30,95})\",\"href"), 1)).otherwise($"id"))

      .withColumn("databaseName", regexp_extract($"id", "//(\\w*)/", 1))
      .withColumn("dbUrl", split($"id", "/"))
      .withColumn("schemaName", $"dburl".getItem(3))
      .withColumn("tableName", $"dburl".getItem(4))
      .withColumn("columnName", $"dburl".getItem(5))
      .withColumn("columnFullName", $"id")
      .withColumn("dbFullName", concat($"dburl".getItem(0), lit("//"), $"databaseName"))
      .withColumn("schemaFullName", concat($"dbFullName", lit("/"), $"schemaName"))
      .withColumn("tableFullName", concat($"schemaFullName", lit("/"), $"tableName"))

      .withColumn("BusinessTermConfidenceScore", regexp_extract($"value",
        ("com.infa.ldm.bg.infTerms\",\"value\":\".*?,(.*?)\""), 1)).withColumn("BusinessTermAssociation", when($"BusinessTermConfidenceScore".isNull or $"BusinessTermConfidenceScore" === "", lit("Manual")).otherwise("Automatic"))
      .withColumn("DataTypeLength", regexp_extract($"value", "attributeId\":\"com.infa.ldm.relational.DatatypeLength\",\"value\":\"(\\d*)\"", 1))
      .withColumn("DataType", regexp_extract($"value", "\"attributeId\":\"com.infa.ldm.relational.Datatype\",\"value\":\"(.*?)\"", 1))
      .withColumn("TechnicalDatatypeFinal", concat($"DataType", lit(":"), $"DataTypeLength"))

    //infoDf.select("servername", "ipAddress", "eaiCode", "schemaname", "tablename", "columnname", "businessterms", "technologyType", "id", "databasename","BusinessTermConfidenceScore",
    // "BusinessTermAssociation","TechnicalDatatypeFinal","geographical_location","columnFullName","dbFullName","schemaFullName","tableFullName")

    infoDf.select("servername", "ipAddress", "eaiCode", "schemaname", "tablename", "columnname", "businessterms", "technologyType", "id", "databasename", "BusinessTermConfidenceScore",
      "BusinessTermAssociation", "TechnicalDatatypeFinal", "columnFullName", "dbFullName", "schemaFullName", "tableFullName")

    //infoDf.select("servername", "ipAddress", "databasename","dbFullName", "schemaname","schemaFullName","tablename","tableFullName", "columnname","columnFullName","TechnicalDatatypeFinal", "businessterms", "eaiCode", "technologyType","BusinessTermConfidenceScore","BusinessTermAssociation", "id")

  }

}

package ie.metlife.process

import ie.metlife.utils.{Authentication, Schema}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructType}

object InvokeEdc {

  def apply(df:DataFrame,spark:SparkSession)={

    import spark.implicits._

    val schema = DataType.fromJson(Schema.edcResponseSchema).asInstanceOf[StructType]

    df.withColumn("response",from_json($"value",schema))
      .withColumn("items",explode($"response.items"))
      .withColumn("id",$"items.id")
      .withColumn("hrefs",$"items.href")
      .withColumn("href",$"items.href")
      .withColumn("href",concat(lit("http://10.65.34.90:9085/access"),$"href",lit("?includeRefObjects=false")))
      .withColumn("secondResponse",Authentication.callForResponse($"href"))
      .drop("response","value")
  }

}


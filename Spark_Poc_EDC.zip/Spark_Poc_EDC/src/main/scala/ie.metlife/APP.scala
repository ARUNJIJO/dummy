package ie.metlife

import ie.metlife.utils.Schema
import org.apache.spark.sql.catalyst.expressions.JsonToStructs
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import scala.io.Source
import java.net.URL

import ie.metlife.utils.Authentication
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.udf
import process.{ExtractCollibraInfo, _}
import java.util.*;
import java.io.*;


object
APP {

  def main(args: Array[String]): Unit = {
    //System.setProperty("hadoop.home.dir","C:\\Selva\\winutils-master\\hadoop-3.0.0")
    //System.setProperty("hadoop.home.dir","C:\\Selva\\winutils-master\\hadoop-2.8.3")

    val inputUrl = Option(args(0)).getOrElse("")
    // Create Spark Session
    val conf = new SparkConf()
    FileReader reader=new FileReader(inputUrl);

    Properties prop =new Properties();
    prop.load(reader);
    val  edcHost = prop.getProperty("edcHost")
    val  edcUrl = prop.getProperty("edcUrl")
    val  edcUsr = prop.getProperty("edcUsr")
    val  edcPwd = prop.getProperty("edcPwd")
    val  collibraUrl = prop.getProperty("collibraUrl")
    val  collibraUsr = prop.getProperty("collibraUsr")
    val  collibraPwd = prop.getProperty("collibraPwd")



    //conf.set("spark.kerberos.keytab", "C:\\Selva\\Workspace\\Java\\Spark_Poc_EDC\\appuserscv01.headless.keyta")
    //conf.set("spark.kerberos.principal", "appuserscv01@GDCQAALICO.CORP")

    //conf.set("spark.kerberos.keytab", "/etc/security/keytabs/appuserscv01.headless.keytab")
    //conf.set("spark.kerberos.principal", "appuserscv01@GDCQAALICO.CORP")

    //conf.set("spark.kerberos.access.hadoopFileSystems", "hdfs://PLLOD1METMGTP01.ALICO.CORP:8020,hdfs://pllod1metaptp02.alico.corp:8020,hdfs://pllod1metaptp01.alico.corp:8020")
    val spark = SparkSession
      .builder()
      .appName(getClass.getSimpleName)
      .config(conf)
      //.master("local[*]")
     .enableHiveSupport()
      .getOrCreate()
    //replace empty string with actual url with filter
    //val jsonResponse = Authentication.getResponse("""http://10.65.34.90:9085/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_8200_Extranet%22)&offset=0&pageSize=5000&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin)

   // val jsonResponse = Authentication.getResponse("""http://10.65.34.90:9085/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_8206_UTAEGUK01%22)&offset=0&pageSize=5000&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin)
   //val jsonResponse = Authentication.getResponse("""https://pllod1metv0041l.alico.corp:9086/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_11725_MetadataUK%22)&offset=0&pageSize=40&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin,"Edcadmin","Edcadminprod")
   //val jsonResponse = Authentication.getResponse("""https://pllod1metv0041l.alico.corp:9086/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_8206_PRAEGUK01%22)&offset=0&pageSize=6000&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin,"Edcadmin","Edcadminprod")

    val jsonResponse = Authentication.getResponse(edcUrl,edcUsr,edcPwd)
    import spark.implicits._
   val responseDf = Seq(jsonResponse).toDF()
   val ids = responseDf
    val edcResponse = InvokeEdc(ids,spark,edcHost,edcUsr,edcPwd)
    val edcInfo   =  ExtractEDCInfo(edcResponse,spark).cache()
    val collibraResponse = Authentication.getResponse(collibraUrl,collibraUsr,collibraPwd)
    val collibraInfo = ExtractCollibraInfo(Seq(collibraResponse).toDF(),spark)
    val colibra_template = edcInfo.join(collibraInfo,usingColumns = Seq("businessterms","eaiCode"),"inner")
    edcInfo.filter($"value".contains("UK_8206_PRAEGUK01~3a~~2f~~2f~PRAEGUK01~2f~dbo~2f~t_Ebd_Claims_Arch~2f~cause_of_death")).show(false)
    /**val df1 = edcInfo.filter("eaicode = 8206")
    val df2 =collibraInfo.filter("businessterms = ''")
    println(df1.count())
    println(df2.count())
    collibraInfo.select("businessterms").distinct().show()**/
    //edcInfo.select("servername").distinct().show()

    //println(df1.join(df2,usingColumns =Seq("eaicode","businessterms"),"inner").distinct.count)
   // colibra_template.show(false)
    colibra_template.repartition(1).select("servername",
    "ipAddress",
    "databasename",
    "dbFullName",
    "schemaname",
    "schemaFullName",
    "tablename",
    "tableFullName",
    "columnname",
    "columnFullName",
    "TechnicalDatatypeFinal",
    "businessterms",
    "eaiCode",
    "technologyType",
    "BusinessTermConfidenceScore",
    "BusinessTermAssociation",
    "collibra_id").write.format("csv").option("header", false).mode("overwrite")
   // Seq("test").toDF().write.mode("overwrite")
     .save("hdfs://PLLOD1METMGTP01.ALICO.CORP:8020/tmp/spark_poc")

    //.write.format("csv").mode("overwrite").save("output")
  }



}

package ie.metlife

import ie.metlife.utils.Schema
import org.apache.spark.sql.catalyst.expressions.JsonToStructs
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import scala.io.Source
import java.net.URL

import ie.metlife.utils.Authentication
import org.apache.spark.sql.functions.udf
import process.{ExtractCollibraInfo, _}


object
APP {

  def main(args: Array[String]): Unit = {

    val inputUrl = Option(args)getOrElse("")
    // Create Spark Session
    val spark = SparkSession
      .builder()
      .appName(getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate()
    //replace empty string with actual url with filter
    //val jsonResponse = Authentication.getResponse("""http://10.65.34.90:9085/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_8200_Extranet%22)&offset=0&pageSize=5000&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin)

    val jsonResponse = Authentication.getResponse("""http://10.65.34.90:9085/access/2/catalog/data/objects?q=(core.classType%3A(%22com.infa.ldm.relational.ViewColumn%22)%20OR%20core.classType%3A(%22com.infa.ldm.relational.Column%22))%20AND%20core.resourceName%3A(%22UK_8206_UTAEGUK01%22)&offset=0&pageSize=5000&includeSrcLinks=true&includeDstLinks=true&includeRefObjects=false""".stripMargin)
    import spark.implicits._
   val responseDf = Seq(jsonResponse).toDF()
   val ids = responseDf
    val edcResponse = InvokeEdc(ids,spark)
    val edcInfo   =  ExtractEDCInfo(edcResponse,spark)
    val collibraResponse = Authentication.getResponse("","","")
    val collibraInfo = ExtractCollibraInfo(Seq(collibraResponse).toDF(),spark)
    val colibra_template = edcInfo.join(collibraInfo,usingColumns = Seq("businessterms","eaiCode"),"inner")

    edcInfo.show()
    collibraInfo.show()
    colibra_template.show(

    )

    val csvHeader = colibra_template.columns.mkString(",").concat("/n").concat(
      colibra_template.as("ds").collect().mkString(",").replace("],[","\n")
        .replace("[","").replace("]",""))

    reflect.io.File("edc.csv").writeAll(csvHeader)
    print(csvHeader)
  }



}

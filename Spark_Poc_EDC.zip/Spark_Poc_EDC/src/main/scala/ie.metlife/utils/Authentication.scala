package ie.metlife.utils

import java.net.URL

import org.apache.commons.codec.binary.Base64
import org.apache.spark.sql.functions.udf
import scalaj.http
import sun.security.util.Password
import scalaj.http._

import scala.io.Source


object Authentication {

  val BASIC = "Basic";
  val AUTHORIZATION = "Authorization";

  def encodeCreds(username: String, password: String): String = {
    new String(Base64.encodeBase64String((username + ":" + password).getBytes));
  };

  def getHeader(username: String, password: String): String =
    BASIC + " " + encodeCreds(username, password);

  def getResponse(url: String,userName:String ="EdcAdmin",password: String="EdcAdmin123"): String = {
    println(url)
    //val connection = new URL(url).openConnection

    //connection.setRequestProperty(Authentication.AUTHORIZATION, Authentication.getHeader(userName,password));
    //val response = Source.fromInputStream(connection.getInputStream);
    val response: HttpResponse[String] = Http(url).header("Authorization",getHeader(userName,password)).options(HttpOptions.allowUnsafeSSL)http.HttpOptions.officialHttpMethods.asString
    Http(url).postMulti(MultiPart())
    response.body

  }

  val callForResponse = udf((x:String) => getResponse(x))
}
